<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ServicesController extends Controller
{
    public function about ()
    {
        return view('Frontend/about/about');
    }
}