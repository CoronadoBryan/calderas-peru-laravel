<?php $__env->startSection('content'); ?>

<section class="services-three services-three--services">
    <div class="container">
        <div class="services-three--services__top">
            <div class="title-box">
                <h2>Estos son nuestros<br>Proyectos</h2>
            </div>
        </div>

        <div class="row">
            <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="services-three__single">
                        <div class="services-three__single-img">
                            <div class="inner" style="width: 100%; height: 250px; overflow: hidden; position: relative;">
                                <!-- Imagen del proyecto -->
                                <img src="<?php echo e(asset('storage/' . $proyecto->imagen_1)); ?>" alt="<?php echo e($proyecto->titulo); ?>" 
                                    style="width: 100%; height: 100%; object-fit: cover; position: absolute;">
                                <div class="icon-box">
                                    <span class="icon-road-transport t5"></span>
                                </div>
                            </div>
                        </div>

                        <div class="services-three__single-content">
                            <div class="services-three__single-content-inner">
                                <h2><?php echo e($proyecto->titulo); ?></h2>
                                <p><?php echo e($proyecto->descripcion); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<style>
.services-three__single-img .inner {
    width: 100%;
    height: 250px; /* Altura fija para todos los div */
    overflow: hidden;
    position: relative;
}

.services-three__single-img .inner img {
    width: 100%;
    height: 100%;
    object-fit: cover; /* Ajusta la imagen al tamaño del contenedor */
    position: absolute;
}
</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bryan\OneDrive\Desktop\calderas\resources\views/Frontend/services/proyects.blade.php ENDPATH**/ ?>