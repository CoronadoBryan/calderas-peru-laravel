<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Crear Proyecto')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">
            <div class="espacio bg-white dark:bg-gray-800 shadow-md rounded-lg">
                <h2 class="text-3xl font-bold mb-8 text-gray-800 dark:text-gray-200"><?php echo e(__('Crear Proyecto')); ?></h2>
                <p class="text-sm text-gray-500 dark:text-gray-400 mb-8">
                    <?php echo e(__('Completa los campos para agregar un nuevo proyecto. Todos los campos son obligatorios.')); ?>

                </p>

                <form method="POST" action="<?php echo e(route('proyectos.store')); ?>" enctype="multipart/form-data" class="space-y-8">
                    <?php echo csrf_field(); ?>

                    <!-- Título -->
                    <div class="space-y-2">
                        <label for="titulo" class="block text-sm font-medium text-gray-700 dark:text-gray-300"><?php echo e(__('Título')); ?></label>
                        <input type="text" name="titulo" id="titulo" value="<?php echo e(old('titulo')); ?>" required
                            class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300">
                        <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Descripción -->
                    <div class="space-y-2">
                        <label for="descripcion" class="block text-sm font-medium text-gray-700 dark:text-gray-300"><?php echo e(__('Descripción')); ?></label>
                        <textarea name="descripcion" id="descripcion" rows="4" required
                            class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"><?php echo e(old('descripcion')); ?></textarea>
                        <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Imágenes -->
                    <div class="space-y-4">
                        <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200"><?php echo e(__('Imágenes del Proyecto')); ?></h3>
                        <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">
                            <?php echo e(__('Sube hasta 6 imágenes. Todas son obligatorias y deben ser en formato JPEG, PNG o JPG con un tamaño máximo de 2MB.')); ?>

                        </p>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            <?php for($i = 1; $i <= 6; $i++): ?>
                                <div class="space-y-2">
                                    <div class="relative group">
                                        <!-- Image Preview Container -->
                                        <div id="preview_container_<?php echo e($i); ?>" class="w-full h-48 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center overflow-hidden border-2 border-dashed border-gray-300 dark:border-gray-600 mb-2">
                                            <div id="placeholder_<?php echo e($i); ?>" class="text-center p-4">
                                                <svg class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                                                    <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                                <p class="mt-1 text-sm text-gray-500 dark:text-gray-400"><?php echo e(__('Imagen ') . $i); ?></p>
                                            </div>
                                            <img id="preview_<?php echo e($i); ?>" class="hidden w-full h-full object-cover" src="#" alt="Preview">
                                        </div>
                                        
                                        <!-- File Input -->
                                        <input type="file" name="imagen_<?php echo e($i); ?>" id="imagen_<?php echo e($i); ?>" required accept="image/jpeg,image/png,image/jpg"
                                            class="absolute inset-0 w-full h-48 opacity-0 cursor-pointer z-10"
                                            onchange="previewImage(this, <?php echo e($i); ?>)">
                                            
                                        <!-- Overlay for hover effect -->
                                        <div class="absolute inset-0 w-full h-48 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300 rounded-lg flex items-center justify-center">
                                            <span class="text-white opacity-0 group-hover:opacity-100 font-medium"><?php echo e(__('Seleccionar imagen')); ?></span>
                                        </div>
                                    </div>
                                    
                                    <div class="flex items-center justify-between">
                                        <label for="imagen_<?php echo e($i); ?>" class="block text-sm font-medium text-gray-700 dark:text-gray-300"><?php echo e(__('Imagen ') . $i); ?></label>
                                        <button type="button" onclick="clearImage(<?php echo e($i); ?>)" id="clear_<?php echo e($i); ?>" class="hidden text-xs text-red-500 hover:text-red-700">
                                            <?php echo e(__('Eliminar')); ?>

                                        </button>
                                    </div>
                                    
                                    <?php $__errorArgs = ["imagen_$i"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endfor; ?>
                        </div>
                    </div>

                    <!-- Botón de guardar -->
                    <div class="flex justify-end mt-10">
                        <button type="submit"
                            class="px-8 py-3 bg-indigo-600 text-white text-sm font-medium rounded-lg shadow-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 dark:bg-indigo-500 dark:hover:bg-indigo-600">
                            <?php echo e(__('Guardar Proyecto')); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function previewImage(input, index) {
            const preview = document.getElementById(`preview_${index}`);
            const placeholder = document.getElementById(`placeholder_${index}`);
            const clearButton = document.getElementById(`clear_${index}`);
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.classList.remove('hidden');
                    placeholder.classList.add('hidden');
                    clearButton.classList.remove('hidden');
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        function clearImage(index) {
            const input = document.getElementById(`imagen_${index}`);
            const preview = document.getElementById(`preview_${index}`);
            const placeholder = document.getElementById(`placeholder_${index}`);
            const clearButton = document.getElementById(`clear_${index}`);
            
            input.value = '';
            preview.src = '#';
            preview.classList.add('hidden');
            placeholder.classList.remove('hidden');
            clearButton.classList.add('hidden');
        }
    </script>

    <?php $__env->startPush('styles'); ?>
        <style>
            .espacio {
                padding: 100px !important;
            }
        </style>
        
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Bryan\OneDrive\Desktop\calderas\resources\views/services/create_proyecto.blade.php ENDPATH**/ ?>