<div class="col-xl-4">
                        <div class="sidebar">
                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__search wow fadeInUp" data-wow-delay=".1s">
                                <div class="title-box">
                                    <h2>Search</h2>
                                </div>
                                <form action="#" class="sidebar__search-form">
                                    <input type="search" placeholder="Search Here...">
                                    <button type="submit"><i class="icon-magnifying-glass"></i></button>
                                </form>
                            </div>
                            <!--End Sidebar Single-->

                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__services wow fadeInUp" data-wow-delay=".2s">
                                <div class="title-box">
                                    <h2>Services List</h2>
                                </div>
                                <ul class="sidebar__services-list">
                                    <li><a href="<?php echo e(route('roadTransport')); ?>">Road Transport <span class="icon-right-arrow-5"></span></a></li>
                                    <li><a href="<?php echo e(route('airTransport')); ?>">Air Transport <span class="icon-right-arrow-5"></span></a></li>
                                    <li><a href="<?php echo e(route('cargoTransport')); ?>">Cargo Transport <span class="icon-right-arrow-5"></span></a></li>
                                    <li><a href="<?php echo e(route('oceanFreight')); ?>">Ocean Freight <span class="icon-right-arrow-5"></span></a></li>
                                    <li><a href="<?php echo e(route('railTransport')); ?>">Rail Transport <span class="icon-right-arrow-5"></span></a></li>
                                    <li><a href="<?php echo e(route('warehousing')); ?>">Warehousing <span class="icon-right-arrow-5"></span></a></li>
                                </ul>
                            </div>
                            <!--End Sidebar Single-->

                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__brochure wow fadeInUp" data-wow-delay=".3s">
                                <div class="title-box">
                                    <h2>Brochure</h2>
                                </div>
                                <div class="sidebar__brochure-box">
                                    <div class="sidebar__brochure-single active">
                                        <div class="left-content">
                                            <div class="icon">
                                                <img src="<?php echo e(asset('assets/img/icon/sidebar-icon1.png')); ?>" alt="">
                                            </div>
                                            <div class="text-box">
                                                <h4>Service Brochure</h4>
                                                <ul>
                                                    <li>
                                                        <p>PDF</p>
                                                    </li>
                                                    <li>
                                                        <p>13 MB</p>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>

                                        <div class="btn-box">
                                            <a href="#"><span class="icon-right-arrow-5"></span></a>
                                        </div>
                                    </div>

                                    <div class="sidebar__brochure-single">
                                        <div class="left-content">
                                            <div class="icon">
                                                <img src="<?php echo e(asset('assets/img/icon/sidebar-icon2.png')); ?>" alt="">
                                            </div>
                                            <div class="text-box">
                                                <h4>Company Profile</h4>
                                                <ul>
                                                    <li>
                                                        <p>Word</p>
                                                    </li>
                                                    <li>
                                                        <p>25 MB</p>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>

                                        <div class="btn-box">
                                            <a href="#"><span class="icon-right-arrow-5"></span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--End Sidebar Single-->

                            <!--Start Sidebar Single-->
                            <div class="sidebar__single sidebar__contact wow fadeInUp" data-wow-delay=".4s">
                                <div class="sidebar__contact-bg" style="background-image: url('<?php echo e(asset('assets/img/service/services-details-img3.jpg')); ?>');"></div>
                                <div class="sidebar__contact-box">
                                    <div class="title">
                                        <h2>Any Question?</h2>
                                    </div>

                                    <div class="sidebar__contact-box-bottom">
                                        <div class="icon-box">
                                            <span class="icon-out-call"></span>
                                        </div>

                                        <div class="text-box">
                                            <p>Call Us Now</p>
                                            <h2><a href="tel:123456789">+70 264 566 579</a></h2>
                                        </div>
                                    </div>
                                </div>
                                <!--End Sidebar Single-->
                            </div>
                        </div>
                    </div><?php /**PATH C:\Users\Bryan\OneDrive\Desktop\calderas\resources\views/components/sidebar.blade.php ENDPATH**/ ?>