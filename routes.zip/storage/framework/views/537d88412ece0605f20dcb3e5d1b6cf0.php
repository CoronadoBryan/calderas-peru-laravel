    <!-- preloader -->
    <div id="preloader">
        <div id="loading-center">
            <div class="loader">
                <div class="loader-outter"></div>
                <div class="loader-inner"></div>
            </div>
        </div>
    </div>
    <!-- preloader-end --><?php /**PATH C:\Users\Bryan\OneDrive\Desktop\calderas\resources\views/components/preloader.blade.php ENDPATH**/ ?>