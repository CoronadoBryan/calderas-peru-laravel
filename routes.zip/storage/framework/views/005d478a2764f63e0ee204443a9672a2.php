<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4"><?php echo e(__('Proyectos')); ?></h3>

                    <!-- Botón para agregar un nuevo proyecto -->
                    <div class="mb-4">
                        <a href="<?php echo e(route('create')); ?>" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                            <?php echo e(__('Agregar Proyecto')); ?>

                        </a>
                    </div>

                    <!-- Tabla de proyectos -->
                    <div class="overflow-x-auto">
                        <table class="min-w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
                            <thead>
                                <tr>
                                    <th class="px-4 py-2 border-b dark:border-gray-700 text-left text-sm font-medium text-gray-500 dark:text-gray-400">
                                        <?php echo e(__('Título')); ?>

                                    </th>
                                    <th class="px-4 py-2 border-b dark:border-gray-700 text-left text-sm font-medium text-gray-500 dark:text-gray-400">
                                        <?php echo e(__('Descripción')); ?>

                                    </th>
                                    <th class="px-4 py-2 border-b dark:border-gray-700 text-left text-sm font-medium text-gray-500 dark:text-gray-400">
                                        <?php echo e(__('Acciones')); ?>

                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="px-4 py-2 border-b dark:border-gray-700 text-sm text-gray-900 dark:text-gray-100">
                                            <?php echo e($proyecto->titulo); ?>

                                        </td>
                                        <td class="px-4 py-2 border-b dark:border-gray-700 text-sm text-gray-900 dark:text-gray-100">
                                            <?php echo e(Str::limit($proyecto->descripcion, 50)); ?>

                                        </td>
                                        <td class="px-4 py-2 border-b dark:border-gray-700 text-sm text-gray-900 dark:text-gray-100">
                                            <a href="<?php echo e(route('proyectos.edit', $proyecto->id)); ?>" class="text-blue-500 hover:underline">
                                                <?php echo e(__('Editar')); ?>

                                            </a>
                                            <form action="<?php echo e(route('proyectos.destroy', $proyecto->id)); ?>" method="POST" class="inline-block ml-2">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="text-red-500 hover:underline">
                                                    <?php echo e(__('Eliminar')); ?>

                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="3" class="px-4 py-2 text-center text-sm text-gray-500 dark:text-gray-400">
                                            <?php echo e(__('No hay proyectos disponibles.')); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Bryan\OneDrive\Desktop\calderas\resources\views/dashboard.blade.php ENDPATH**/ ?>