    <!-- Scroll-top -->
    <button class="scroll-top scroll-to-target" data-target="html">
        <i class="icon-up"></i>
    </button>
    <!-- Scroll-top-end--><?php /**PATH C:\Users\Bryan\OneDrive\Desktop\calderas\resources\views/components/scrolltop.blade.php ENDPATH**/ ?>