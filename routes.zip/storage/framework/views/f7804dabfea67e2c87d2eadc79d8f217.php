    <!-- JS here -->
    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/ajax-form.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.appear.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.circleType.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.lettering.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.odometer.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery-sidebar-content.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/nouislider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/swiper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
    <?php echo (isset($script) ? $script   : '')?>

    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script><?php /**PATH C:\Users\Bryan\OneDrive\Desktop\calderas\resources\views/components/script.blade.php ENDPATH**/ ?>