<div class="search-popup">
    <div class="search-popup__overlay search-toggler">
        <div class="search-popup__close-icon">
            <span class="icon-plus"></span>
        </div>
    </div>
    <div class="search-popup__content">
        <form action="#">
            <label for="search" class="sr-only">search here</label>
            <input type="text" id="search" placeholder="Search Here..." />
            <button type="submit" aria-label="search submit" class="btn-box">
                <i class="icon-magnifying-glass"></i>
            </button>
        </form>
    </div>
</div><?php /**PATH C:\Users\Bryan\OneDrive\Desktop\calderas\resources\views/components/searchPopUp.blade.php ENDPATH**/ ?>